"""Smart Library - Flask + SQLite backend (Team Code Crafters, MIST).
Run: pip install flask qrcode[pil] werkzeug && python app.py"""
import sqlite3, secrets, re, io, base64, hashlib, os, time
from datetime import date, datetime, timedelta
from functools import wraps
from flask import Flask, g, jsonify, request, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash

DB = "library.db"
app = Flask(__name__, static_folder="assets", static_url_path="/assets")  # never serve "." (it holds library.db and app.py)
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024
MAX_LOANS, LOAN_DAYS = 3, 14
POLICY = {"rate": 2, "tier_days": 6, "rate_after": 5, "grace_days": 0, "cap": 500, "working_days": False, "holidays": []}

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, card_uid TEXT UNIQUE, name TEXT NOT NULL,
  email TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN('student','faculty','librarian','admin')), pw_hash TEXT);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), expires TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS books(id INTEGER PRIMARY KEY, qr_payload TEXT UNIQUE, title TEXT NOT NULL, author TEXT,
  subject TEXT, isbn TEXT UNIQUE, total INTEGER NOT NULL CHECK(total>0), available INTEGER NOT NULL CHECK(available>=0),
  assigned_location TEXT, last_verified_location TEXT, audit_status TEXT DEFAULT 'Verified'
  CHECK(audit_status IN('Verified','Wrong place','Not found - needs verification')),
  scan_front TEXT NOT NULL, scan_back TEXT NOT NULL, scan_index TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS loans(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
  book_id INTEGER NOT NULL REFERENCES books(id), issued TEXT NOT NULL, due TEXT NOT NULL, returned TEXT,
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(status IN('ACTIVE','OVERDUE','RETURNED')), fine INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS receipts(code TEXT PRIMARY KEY, loan_id INTEGER NOT NULL REFERENCES loans(id),
  kind TEXT NOT NULL CHECK(kind IN('ISSUE','RETURN')), used INTEGER DEFAULT 0, created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS reservations(id INTEGER PRIMARY KEY, user_id INTEGER, book_id INTEGER, created TEXT,
  status TEXT DEFAULT 'WAITING', UNIQUE(user_id, book_id));
CREATE TABLE IF NOT EXISTS auth_log(id INTEGER PRIMARY KEY, at TEXT, ip TEXT, who TEXT, ok INTEGER);
CREATE TABLE IF NOT EXISTS loan_scans(loan_id INTEGER PRIMARY KEY REFERENCES loans(id), front TEXT NOT NULL, back TEXT NOT NULL, idx TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS arrivals(id INTEGER PRIMARY KEY, user_id INTEGER, title TEXT NOT NULL, note TEXT, created TEXT);
CREATE TABLE IF NOT EXISTS shelves(id TEXT PRIMARY KEY, category TEXT, capacity INTEGER, occupied INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS book_movements(id INTEGER PRIMARY KEY, book_id INTEGER, from_loc TEXT, to_loc TEXT,
  by_user INTEGER, at TEXT);
CREATE TABLE IF NOT EXISTS fine_log(id INTEGER PRIMARY KEY, loan_id INTEGER, amount INTEGER, by_user INTEGER, reason TEXT, at TEXT);
"""

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB); g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db

@app.teardown_appcontext
def close(_): d = g.pop("db", None); d and d.close()

def init():
    c = sqlite3.connect(DB); c.executescript(SCHEMA)
    if not c.execute("SELECT 1 FROM users WHERE email='librarian@mist.edu'").fetchone():
        pw = os.environ.get("LIB_ADMIN_PASSWORD") or secrets.token_urlsafe(12)
        c.execute("INSERT INTO users(card_uid,name,email,role,pw_hash) VALUES(?,?,?,?,?)", (None, "Head Librarian", "librarian@mist.edu", "librarian", generate_password_hash(pw)))
        print("First run. Librarian login: librarian@mist.edu /", pw, "(shown once; set LIB_ADMIN_PASSWORD to choose your own)")
    c.executemany("INSERT OR IGNORE INTO shelves VALUES(?,?,?,0)",
                  [("B02-S03", "Computer Science", 40), ("B02-S04", "Computer Science", 40), ("A-R02-C02", "Biochemistry", 27)])
    for i, (t, au, s, isbn, n, loc) in enumerate(SEED):  # sample B.Tech titles; ISBNs are placeholders
        c.execute("INSERT OR IGNORE INTO books(id,qr_payload,title,author,subject,isbn,total,available,assigned_location,last_verified_location,scan_front,scan_back,scan_index) VALUES(?,?,?,?,?,?,?,?,?,?,'seed','seed','seed')",
                  (1029 + i, f"BK{1029 + i}", t, au, s, isbn, n, n, loc, loc))
    c.executemany("INSERT OR IGNORE INTO shelves VALUES(?,?,?,0)", [("B03-S01", "Electronics", 40), ("B03-S02", "Electrical", 40), ("B04-S01", "Mechanical", 40), ("B04-S02", "Civil", 40), ("B01-S01", "Mathematics", 40), ("B01-S02", "Physics", 40), ("B01-S03", "Chemistry", 40)])
    c.commit(); c.close()

SEED = [["Introduction to Algorithms", "Thomas H. Cormen", "Computer Science", "9780000000001", 3, "B02-S03-P01"], ["Database System Concepts", "Abraham Silberschatz", "Computer Science", "9780000000002", 3, "B02-S03-P02"], ["Data Structures Using C", "Reema Thareja", "Computer Science", "9780000000003", 3, "B02-S03-P03"], ["Let Us C", "Yashavant Kanetkar", "Computer Science", "9780000000004", 3, "B02-S03-P04"], ["Artificial Intelligence: A Modern Approach", "Stuart Russell, Peter Norvig", "Computer Science", "9780000000005", 3, "B02-S03-P05"], ["Software Engineering: A Practitioner's Approach", "Roger S. Pressman", "Computer Science", "9780000000006", 3, "B02-S03-P06"], ["Compilers: Principles, Techniques and Tools", "Alfred V. Aho", "Computer Science", "9780000000007", 3, "B02-S03-P07"], ["Introduction to the Theory of Computation", "Michael Sipser", "Computer Science", "9780000000008", 3, "B02-S03-P08"], ["Microelectronic Circuits", "Sedra and Smith", "Electronics", "9780000000009", 3, "B03-S01-P09"], ["Digital Design", "M. Morris Mano", "Electronics", "9780000000010", 3, "B03-S01-P10"], ["Signals and Systems", "Alan V. Oppenheim", "Electronics", "9780000000011", 3, "B03-S01-P11"], ["Communication Systems", "Simon Haykin", "Electronics", "9780000000012", 3, "B03-S01-P12"], ["Fundamentals of Electric Circuits", "Alexander and Sadiku", "Electrical", "9780000000013", 3, "B03-S02-P13"], ["Engineering Thermodynamics", "P. K. Nag", "Mechanical", "9780000000014", 3, "B04-S01-P14"], ["Theory of Machines", "S. S. Rattan", "Mechanical", "9780000000015", 3, "B04-S01-P15"], ["Structural Analysis", "R. C. Hibbeler", "Civil", "9780000000016", 3, "B04-S02-P16"], ["Higher Engineering Mathematics", "B. S. Grewal", "Mathematics", "9780000000017", 3, "B01-S01-P17"], ["Advanced Engineering Mathematics", "Erwin Kreyszig", "Mathematics", "9780000000018", 3, "B01-S01-P18"], ["Engineering Physics", "Gaur and Gupta", "Physics", "9780000000019", 3, "B01-S02-P19"], ["Engineering Chemistry", "Jain and Jain", "Chemistry", "9780000000020", 3, "B01-S03-P20"]]

# ---------- fine engine ----------
def calculate_fine(due, returned, policy=POLICY):
    """No fine on/before due date. Grace days, working-day mode, holidays and cap supported."""
    if returned <= due: return 0
    days, d = 0, due
    while d < returned:
        d += timedelta(days=1)
        if policy["working_days"] and (d.weekday() >= 5 or d.isoformat() in policy["holidays"]): continue
        days += 1
    days = max(0, days - policy["grace_days"])
    first = min(days, policy["tier_days"])  # Rs 2/day for the first 6 late days, then Rs 5/day
    return min(first * policy["rate"] + (days - first) * policy["rate_after"], policy["cap"])

# ---------- auth & security ----------
FAILS = {}
def ip(): return request.remote_addr or "?"
def locked(k): return FAILS.get(k, (0, 0))[1] > time.time()
def bump(k):
    n = FAILS.get(k, (0, 0))[0] + 1
    FAILS[k] = (0, time.time() + 300) if n >= 5 else (n, 0)  # 5 wrong tries = 5 minute lock
def log_auth(who, ok):
    db().execute("INSERT INTO auth_log(at,ip,who,ok) VALUES(?,?,?,?)", (datetime.utcnow().isoformat(), ip(), who[:120], int(ok))); db().commit()

@app.after_request
def secure(r):
    r.headers.update({"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer",
        "Content-Security-Policy": "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"})
    if request.path.startswith("/api/"): r.headers["Cache-Control"] = "no-store"
    return r

def make_token(uid):
    t = secrets.token_urlsafe(32)
    db().execute("INSERT INTO sessions VALUES(?,?,?)", (hashlib.sha256(t.encode()).hexdigest(), uid,  # only the hash is stored
 (datetime.utcnow() + timedelta(hours=8)).isoformat()))
    db().commit(); return t

def auth(*roles):
    def deco(f):
        @wraps(f)
        def w(*a, **k):
            t = hashlib.sha256(request.headers.get("Authorization", "").replace("Bearer ", "").encode()).hexdigest(); g.token = t
            r = db().execute("SELECT u.*, s.expires FROM sessions s JOIN users u ON u.id=s.user_id WHERE token=?", (t,)).fetchone()
            if not r or r["expires"] < datetime.utcnow().isoformat(): return jsonify(error="Sign in again"), 401
            if roles and r["role"] not in roles: return jsonify(error="Not allowed for your role"), 403
            g.user = r; return f(*a, **k)
        return w
    return deco

STUDENT = re.compile(r"^\d{7}$"); FAC = re.compile(r"^FAC-\d{4}-\d{4}$"); MAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

@app.post("/api/auth/card")
def card_login():
    j = request.get_json(silent=True) or {}; uid = str(j.get("card_uid") or "").strip().upper(); key = (ip(), "card")
    if locked(key): return jsonify(error="Too many tries. Wait 5 minutes."), 429
    if j.get("blurry"): return jsonify(error="Scan was blurry. Hold the card flat and scan again."), 422
    role = "faculty" if FAC.match(uid) else "student" if STUDENT.match(uid) else None  # role comes from the ID, never from the client
    if not role:
        bump(key); log_auth(uid, 0)
        return jsonify(error="Enrollment numbers have 7 digits, like 2026022. Faculty IDs look like FAC-2026-0102."), 422
    u = db().execute("SELECT * FROM users WHERE card_uid=?", (uid,)).fetchone()
    if not u:
        name, email = str(j.get("name") or "").strip()[:80], str(j.get("email") or "").strip()[:120]
        if not name or not MAIL.match(email): return jsonify(need_registration=True), 202
        cur = db().execute("INSERT INTO users(card_uid,name,email,role) VALUES(?,?,?,?)", (uid, name, email, role))
        db().commit(); u = db().execute("SELECT * FROM users WHERE id=?", (cur.lastrowid,)).fetchone()
    log_auth(uid, 1)
    return jsonify(token=make_token(u["id"]), name=u["name"], role=u["role"])

DUMMY = generate_password_hash("not-a-real-password")  # equal timing whether or not the email exists

@app.post("/api/auth/staff")
def staff_login():
    j = request.get_json(silent=True) or {}; email = str(j.get("email", "")).strip().lower()[:120]; key = (ip(), "staff")
    if locked(key): return jsonify(error="Too many tries. Wait 5 minutes."), 429
    u = db().execute("SELECT * FROM users WHERE email=? AND role IN('librarian','admin')", (email,)).fetchone()
    ok = check_password_hash(u["pw_hash"] if u else DUMMY, str(j.get("password", "")))
    if not (u and ok): bump(key); log_auth(email, 0); return jsonify(error="Wrong email or password"), 401
    log_auth(email, 1); return jsonify(token=make_token(u["id"]), name=u["name"], role=u["role"])

@app.post("/api/auth/logout")
@auth()
def logout():
    db().execute("DELETE FROM sessions WHERE token=?", (g.token,)); db().commit(); return jsonify(ok=True)

# ---------- catalog ----------
@app.get("/api/books")
def books():
    q = f"%{request.args.get('q', '')}%"
    sql = "SELECT id,qr_payload,title,author,subject,isbn,total,available,assigned_location FROM books WHERE (title LIKE ? OR author LIKE ? OR subject LIKE ? OR isbn LIKE ? OR qr_payload LIKE ?)"
    args = [q] * 5
    if request.args.get("available") == "1": sql += " AND available>0"
    if request.args.get("subject"): sql += " AND subject=?"; args.append(request.args["subject"])
    return jsonify([dict(r) for r in db().execute(sql + " LIMIT 100", args)])

@app.post("/api/books")
@auth("librarian", "admin")
def add_book():
    j = request.get_json(force=True)
    if not all(j.get(k) for k in ("scan_front", "scan_back", "scan_index")): return jsonify(error="Attach all 3 page scans before saving"), 422
    isbn = re.sub(r"[^0-9Xx]", "", j.get("isbn", ""))
    if len(isbn) not in (10, 13): return jsonify(error="ISBN must have 10 or 13 digits"), 422
    if db().execute("SELECT 1 FROM books WHERE isbn=?", (isbn,)).fetchone(): return jsonify(error="This ISBN is already registered"), 409
    n = int(j.get("total", 0))
    if n < 1: return jsonify(error="Copies must be at least 1"), 422
    nxt = (db().execute("SELECT COALESCE(MAX(id),1024)+1 FROM books").fetchone()[0])
    db().execute("INSERT INTO books(id,qr_payload,title,author,subject,isbn,total,available,assigned_location,last_verified_location,scan_front,scan_back,scan_index) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                 (nxt, f"BK{nxt}", j["title"], j.get("author"), j.get("subject"), isbn, n, n, j.get("location"), j.get("location"),
                  j["scan_front"], j["scan_back"], j["scan_index"]))
    db().commit(); return jsonify(id=nxt, qr_payload=f"BK{nxt}"), 201

@app.get("/api/books/<payload>/qr")
def qr(payload):
    import qrcode
    buf = io.BytesIO(); qrcode.make(payload).save(buf, "PNG")
    return jsonify(png="data:image/png;base64," + base64.b64encode(buf.getvalue()).decode())

# ---------- loans & receipts ----------
def rcode(kind, loan_id): return f"{'ISS' if kind=='ISSUE' else 'RET'}-{loan_id:05d}-{secrets.token_hex(2).upper()}"

@app.post("/api/loans")
@auth("librarian", "admin")
def borrow():
    j = request.get_json(force=True); d = db()
    u = d.execute("SELECT * FROM users WHERE card_uid=?", (j.get("card_uid", "").upper(),)).fetchone()
    b = d.execute("SELECT * FROM books WHERE qr_payload=?", (j.get("qr_payload"),)).fetchone()
    if not u or not b: return jsonify(error="Card or book not found"), 404
    if u["role"] == "student" and d.execute("SELECT COUNT(*) FROM loans WHERE user_id=? AND status!='RETURNED'", (u["id"],)).fetchone()[0] >= MAX_LOANS:
        return jsonify(error="Limit reached: 3 active books"), 409
    if b["available"] < 1: return jsonify(error="No copy available. Reserve it instead."), 409
    sc = [j.get(k) for k in ("scan_front", "scan_back", "scan_index")]  # 3 page scans required at issue
    if not all(isinstance(s, str) and 0 < len(s) < 3_000_000 for s in sc): return jsonify(error="Scan the front, back and index pages before issuing"), 422
    today = date.today()
    cur = d.execute("INSERT INTO loans(user_id,book_id,issued,due) VALUES(?,?,?,?)", (u["id"], b["id"], today.isoformat(), (today + timedelta(days=LOAN_DAYS)).isoformat()))
    d.execute("INSERT INTO loan_scans VALUES(?,?,?,?)", (cur.lastrowid, *sc))
    code = rcode("ISSUE", cur.lastrowid)
    d.execute("INSERT INTO receipts VALUES(?,?,?,0,?)", (code, cur.lastrowid, "ISSUE", datetime.utcnow().isoformat()))
    d.execute("UPDATE books SET available=available-1 WHERE id=?", (b["id"],)); d.commit()
    return jsonify(receipt=code, due=(today + timedelta(days=LOAN_DAYS)).isoformat()), 201

@app.post("/api/receipts/verify")
@auth("librarian", "admin")
def verify():
    r = db().execute("SELECT * FROM receipts WHERE code=? AND kind='ISSUE'", (request.get_json(force=True).get("code", ""),)).fetchone()
    if not r: return jsonify(error="Receipt not found"), 404
    if r["used"]: return jsonify(error="Receipt already verified once"), 409
    db().execute("UPDATE receipts SET used=1 WHERE code=?", (r["code"],)); db().commit(); return jsonify(ok=True)

@app.post("/api/loans/<int:lid>/return")
@auth("librarian", "admin")
def give_back(lid):
    d = db(); l = d.execute("SELECT * FROM loans WHERE id=?", (lid,)).fetchone()
    if not l: return jsonify(error="Loan not found"), 404
    if l["status"] == "RETURNED": return jsonify(error="Already returned. No second fine applied."), 409
    today = date.today(); fine = calculate_fine(date.fromisoformat(l["due"]), today)
    d.execute("UPDATE loans SET returned=?,status='RETURNED',fine=? WHERE id=?", (today.isoformat(), fine, lid))
    d.execute("UPDATE books SET available=available+1 WHERE id=?", (l["book_id"],))
    code = rcode("RETURN", lid); d.execute("INSERT INTO receipts VALUES(?,?,?,0,?)", (code, lid, "RETURN", datetime.utcnow().isoformat()))
    w = d.execute("SELECT id FROM reservations WHERE book_id=? AND status='WAITING' ORDER BY created LIMIT 1", (l["book_id"],)).fetchone()
    if w: d.execute("UPDATE reservations SET status='READY' WHERE id=?", (w["id"],))  # single winner: first in queue
    d.commit(); return jsonify(receipt=code, returned=today.isoformat(), fine=fine, reservation_ready=bool(w))

@app.post("/api/loans/<int:lid>/adjust-fine")
@auth("admin")
def adjust(lid):
    j = request.get_json(force=True); amt = int(j.get("amount", 0))
    if amt < 0 or not j.get("reason"): return jsonify(error="Amount and reason required"), 422
    db().execute("UPDATE loans SET fine=? WHERE id=?", (amt, lid))
    db().execute("INSERT INTO fine_log(loan_id,amount,by_user,reason,at) VALUES(?,?,?,?,?)", (lid, amt, g.user["id"], j["reason"], datetime.utcnow().isoformat()))
    db().commit(); return jsonify(ok=True)

@app.post("/api/reservations")
@auth("student", "faculty")
def reserve():
    try:
        db().execute("INSERT INTO reservations(user_id,book_id,created) VALUES(?,?,?)", (g.user["id"], request.get_json(force=True)["book_id"], datetime.utcnow().isoformat()))
        db().commit()
    except sqlite3.IntegrityError: return jsonify(error="Already in the queue"), 409
    return jsonify(ok=True), 201

# ---------- reshelving (decision support: librarian confirms) ----------
@app.post("/api/reshelve/suggest")
@auth("librarian", "admin")
def suggest():
    b = db().execute("SELECT * FROM books WHERE qr_payload=?", (request.get_json(force=True).get("qr_payload"),)).fetchone()
    if not b: return jsonify(error="Book not found"), 404
    rows = db().execute("SELECT *, capacity-occupied AS free FROM shelves WHERE category=? AND capacity-occupied>0 ORDER BY free DESC", (b["subject"],)).fetchall()
    if not rows: return jsonify(suggestion=None, note="No compatible shelf has space. Ask the librarian to free a shelf."), 200
    return jsonify(suggestion=rows[0]["id"], alternatives=[r["id"] for r in rows[1:]], needs_confirmation=True)

@app.post("/api/reshelve/confirm")
@auth("librarian", "admin")
def confirm():
    j = request.get_json(force=True); d = db()
    b = d.execute("SELECT * FROM books WHERE qr_payload=?", (j.get("qr_payload"),)).fetchone()
    if not b: return jsonify(error="Book not found"), 404
    d.execute("UPDATE books SET assigned_location=?,last_verified_location=?,audit_status='Verified' WHERE id=?", (j["to"], j["to"], b["id"]))
    d.execute("INSERT INTO book_movements(book_id,from_loc,to_loc,by_user,at) VALUES(?,?,?,?,?)", (b["id"], b["assigned_location"], j["to"], g.user["id"], datetime.utcnow().isoformat()))
    d.commit(); return jsonify(ok=True)

@app.post("/api/loans/<int:lid>/extend")
@auth("faculty", "librarian", "admin")
def extend(lid):
    l = db().execute("SELECT * FROM loans WHERE id=? AND status='ACTIVE'", (lid,)).fetchone()
    if not l: return jsonify(error="Only active loans can be extended"), 404
    if g.user["role"] == "faculty" and l["user_id"] != g.user["id"]: return jsonify(error="Not your loan"), 403
    new = (date.fromisoformat(l["due"]) + timedelta(days=7)).isoformat()
    db().execute("UPDATE loans SET due=? WHERE id=?", (new, lid)); db().commit(); return jsonify(due=new)

@app.post("/api/arrivals")
@auth("student", "faculty")
def arrival():
    j = request.get_json(force=True)
    if not (j.get("title") or "").strip(): return jsonify(error="Add a title"), 422
    db().execute("INSERT INTO arrivals(user_id,title,note,created) VALUES(?,?,?,?)", (g.user["id"], j["title"].strip(), j.get("note"), datetime.utcnow().isoformat()))
    db().commit(); return jsonify(ok=True), 201

@app.post("/api/audit/<payload>")
@auth("librarian", "admin")
def audit(payload):
    j = request.get_json(force=True)
    if j.get("status") not in ("Verified", "Wrong place", "Not found - needs verification"): return jsonify(error="Unknown status"), 422
    db().execute("UPDATE books SET audit_status=?, last_verified_location=COALESCE(?,last_verified_location) WHERE qr_payload=?", (j["status"], j.get("found_at"), payload))
    db().commit(); return jsonify(ok=True)

@app.get("/api/stats")
@auth("librarian", "admin")
def stats():
    q = lambda s: db().execute(s).fetchone()[0]
    db().execute("UPDATE loans SET status='OVERDUE' WHERE status='ACTIVE' AND due<?", (date.today().isoformat(),)); db().commit()
    return jsonify(total=q("SELECT COALESCE(SUM(total),0) FROM books"), available=q("SELECT COALESCE(SUM(available),0) FROM books"),
                   active=q("SELECT COUNT(*) FROM loans WHERE status!='RETURNED'"), overdue=q("SELECT COUNT(*) FROM loans WHERE status='OVERDUE'"),
                   fines=q("SELECT COALESCE(SUM(fine),0) FROM loans"), mismatches=q("SELECT COUNT(*) FROM books WHERE audit_status!='Verified'"))

@app.get("/")
def index(): return send_from_directory(".", "index.html")

if __name__ == "__main__":
    init(); app.run(debug=False, port=5000)
