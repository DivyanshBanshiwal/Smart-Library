Smart Library - Team Code Crafters, MITS

OPEN THE WEBSITE ONLY (no server):
  Double-click index.html. Logo and photos are built in. Demo data only.

RUN WITH THE PYTHON BACKEND:
  pip install -r requirements.txt
  python app.py
  Open http://127.0.0.1:5000
  First run prints a random librarian password once (user: librarian@mist.edu).
  Set your own with the LIB_ADMIN_PASSWORD environment variable.

DEMO LOGINS (website):
  Student: 2026022   (enrollment numbers are 7 digits)
  Faculty: FAC-2026-0102

FILES:
  index.html          the whole frontend
  app.py              Flask + SQLite backend (fines, QR, receipts, security)
  requirements.txt    Python packages
  assets/             photos and logo (also built into index.html)
  shelf-scan-tour.mp4 recorded shelf scan walkthrough
